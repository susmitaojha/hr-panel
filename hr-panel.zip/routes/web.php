<?php
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\EmployeeController;

route::get('/',[EmployeeController::class,'index']);
route::get('/employee',[EmployeeController::class,'display']);
route::get('/employee-form',[EmployeeController::class,'employeeForm']);
route::post('/add-employee',[EmployeeController::class,'addEmployee']);