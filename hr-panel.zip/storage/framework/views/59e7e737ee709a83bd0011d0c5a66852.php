<footer class="footer">
          <div class="container-fluid d-flex justify-content-between">
             <div class="copyright">
              &2024 - 
              <a href="#">Copywrite</a>
            </div>
          </div>
        </footer><?php /**PATH D:\laravel\hr-panel\resources\views/frontend/footer.blade.php ENDPATH**/ ?>