<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Employee;

class EmployeeController extends Controller
{
    public function index()
    {
        return view('frontend.home');
    }
    public function display()
    {
        $data = Employee::all();
        return view('frontend.employee',['data' => $data]);
    }
    public function employeeForm()
    {
        return view('frontend.addEmployee');
    }
    public function addEmployee(Request $req)
    {
       $validated = $req->validate([
        'fname' => 'required|string|min:5',
        'mname' => 'required|string|min:5',
        'lname' => 'required|string|min:5',
        'email' => 'required|string',
        'gender' => 'required|string',
        'mangername' => 'required|string|min:5',
        'designation' => 'required|string',
        'role' => 'required|string',
        'skills'=>'required',
        'fixedsalary'=> 'required|string'
       ]);
       Employee::create($validated);
       return redirect()->back()->with('success');
    }
}
