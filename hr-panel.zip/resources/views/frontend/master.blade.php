
      <!-- Sidebar -->
      @include('frontend.common.sidebar')
      <!-- End Sidebar -->

        
        @include('frontend.common.navbar')

     

       @include('frontend.common.footer')
      