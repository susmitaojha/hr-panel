
      <!-- Sidebar -->
      @include('frontend.common.sidebar')
      <!-- End Sidebar -->

        
        @include('frontend.common.navbar')
        <div class="container">
          <div class="page-inner">
            <div class="page-header">
              <h3 class="fw-bold mb-3">Forms</h3>
              <ul class="breadcrumbs mb-3">
                <li class="nav-home">
                  <a href="#">
                    <i class="icon-home"></i>
                  </a>
                </li>
                <li class="separator">
                  <i class="icon-arrow-right"></i>
                </li>
                <li class="nav-item">
                  <a href="#">Forms</a>
                </li>
                <li class="separator">
                  <i class="icon-arrow-right"></i>
                </li>
                <li class="nav-item">
                  <a href="#">Basic Form</a>
                </li>
              </ul>
            </div>
            <div class="row">
              <div class="col-md-12">
                <div class="card">
                  <div class="card-header">
                    <div class="card-title">Onboarding Employee</div>
                  </div>
                  <form action="/add-employee" method="post">
                    @csrf
                    <div class="card-body">
                        <div class="row">
                        <div class="col-md-6 col-lg-4">
                            <div class="form-group">
                            <label for="firstName">First Name</label>
                            <input
                                type="text"
                                name="fname"
                                class="form-control"
                                id=""
                                placeholder="Enter First Name"
                            />
                            </div>

                            <div class="form-group">
                            <label for="email">Email Address</label>
                            <input
                                type="email"
                                name="email"
                                class="form-control"
                                id="email"
                                placeholder="Enter Email"
                            />
                            </div>
                            <div class="form-group">
                            <label for="middleName">Designation</label>
                            <input
                                type="text"
                                name="designation"
                                class="form-control"
                                id=""
                                placeholder="Enter Designation"
                            />
                            </div>
                        </div>
                        <div class="col-md-6 col-lg-4">
                            <div class="form-group">
                            <label for="middleName">Middle Name</label>
                            <input
                                type="text"
                                name="mname"
                                class="form-control"
                                id=""
                                placeholder="Enter Middle Name"
                            />
                            </div>
                            <div class="form-group">
                            <label>Gender</label><br />
                            <div class="d-flex">
                                <div class="form-check">
                                <input
                                    class="form-check-input"
                                    type="radio"
                                    name="gender"
                                    value="male"
                                    id="flexRadioDefault1"
                                />
                                <label
                                    class="form-check-label"
                                    for="flexRadioDefault1"
                                >
                                    Male
                                </label>
                                </div>
                                <div class="form-check">
                                <input
                                    class="form-check-input"
                                    type="radio"
                                    value="female"
                                    name="gender"
                                    id="flexRadioDefault2"
                                    checked
                                />
                                <label
                                    class="form-check-label"
                                    for="flexRadioDefault2"
                                >
                                    Female
                                </label>
                                </div>
                            </div>
                            </div>
                            <div class="form-group">
                            <label for="salary">Role</label>
                            <input
                                type="text"
                                class="form-control"
                                name="role"
                                id=""
                                placeholder="Enter Role"
                            />
                            </div>
                    
                        </div>
                        <div class="col-md-6 col-lg-4">
                            <div class="form-group">
                            <label for="lastName">Last Name</label>
                            <input
                                type="text"
                                name="lname"
                                class="form-control"
                                id=""
                                placeholder="Enter Last Name"
                            />
                            </div>
                            <div class="form-group">
                            <label for="middleName">Manager Name</label>
                            <input
                                type="text"
                                name="mangername"
                                class="form-control"
                                id=""
                                placeholder="Enter Manger Name"
                            />
                            </div>
                            <div class="form-group">
                            <label for="salary">Skills</label>
                            <textarea
                                class="form-control"
                                name="skills"
                                aria-label="With textarea"
                                ></textarea>                        
                            </div>
                        </div>
                        </div>
                    </div>
                    <div class="card-header">
                        <div class="card-title">Salary Details</div>
                    </div>
                    <p class="mx-4" >Yearly Salary</p>
                    <div class="card-body">
                        <div class="row">
                        <div class="col-md-6 col-lg-4">
                            <div class="form-group">
                            <label for="fixedSalary">Fixed Salary</label>
                            <input
                                type="number"
                                class="form-control"
                                name="fixedsalary"
                                id=""
                                placeholder="Enter Fixed Salary"
                            />
                            </div>
                        </div>
                        <div class="col-md-6 col-lg-4">
                            <div class="form-group">
                            <label for="variablePay">Veriable Pay</label>
                            <input
                                type="number"
                                class="form-control"
                                id=""
                                placeholder="Enter Variable Pay"
                            />
                            </div>
                        </div>
                        <div class="col-md-6 col-lg-4">
                            <div class="form-group">
                            <label for="lastName">Other Benefits</label>
                            <input
                                type="number"
                                class="form-control"
                                id=""
                                placeholder="Enter Other Benefits"
                            />
                            </div>
                        </div>
                        </div>
                    </div>
                    <div class="card-body">
                        <div class="row">
                        <div class="col-md-6 col-lg-4">
                            <div class="form-group">
                            <label for="fixedSalary">Fixed Salary</label>
                            <input
                                type="number"
                                class="form-control"
                                id=""
                                placeholder="Enter Fixed Salary"
                            />
                            </div>

                            <div class="form-group">
                            <label for="email">Incentive(Total)</label>
                            <input
                                type="number"
                                class="form-control"
                                id=""
                                placeholder="Enter Incentive(Total)"
                            />
                            </div>
                        </div>
                        <div class="col-md-6 col-lg-4">
                            <div class="form-group">
                            <label for="variablePay">Veriable Pay</label>
                            <input
                                type="number"
                                class="form-control"
                                id=""
                                placeholder="Enter Variable Pay"
                            />
                            </div>
                            <div class="form-group">
                            <label for="bonus">Bonus</label>
                            <input
                                type="number"
                                class="form-control"
                                id=""
                                placeholder="Enter Bonus"
                            />
                            </div>
                    
                        </div>
                        <div class="col-md-6 col-lg-4">
                            <div class="form-group">
                            <label for="lastName">Other Benefits</label>
                            <input
                                type="number"
                                class="form-control"
                                id=""
                                placeholder="Enter Other Benefits"
                            />
                            </div>
                            <div class="form-group">
                            <label for="bonus">Annual Salary</label>
                            <input
                                type="number"
                                class="form-control"
                                id=""
                                placeholder="Enter Annual Salary"
                            />
                            </div>
                        </div>
                        </div>
                    </div>
                    <div class="card-action">
                        <button class="btn btn-success">Submit</button>
                        <button class="btn btn-danger">Cancel</button>
                    </div>
                </form>
                </div>
              </div>
            </div>
          </div>
        </div>
     
<footer class="footer">
          <div class="container-fluid d-flex justify-content-between">
             <div class="copyright">
              &2024 - 
              <a href="#">Copywrite</a>
            </div>
          </div>
        </footer>
        </div>

  
</div>
<!--   Core JS Files   -->
<script src="assets/js/core/jquery-3.7.1.min.js"></script>
<script src="assets/js/core/popper.min.js"></script>
<script src="assets/js/core/bootstrap.min.js"></script>

<!-- jQuery Scrollbar -->
<script src="assets/js/plugin/jquery-scrollbar/jquery.scrollbar.min.js"></script>

<!-- Bootstrap Notify -->
<script src="assets/js/plugin/bootstrap-notify/bootstrap-notify.min.js"></script>

<!-- Kaiadmin JS -->
<script src="assets/js/kaiadmin.min.js"></script>
<script>
    @if(session('success'))
    $.notify({
        message: 'Employee Added Succesfully',
    },{
        type: 'success',
        placement: {
            from: "top",
            align: "right"
        },
        time: 1000,
    });
    @endif
</script>
</body>
</html>

      